import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { WeatherService } from 'shared/services/weather.service';
import {ResultsModule} from '../weather-results/results.module';
import { AddressService } from 'shared/services/address.service';
import { HistoricalWeatherServices } from 'shared/services/historical-year.service';


@NgModule({
  imports: [CommonModule, ResultsModule],
  declarations: [],
  providers: [WeatherService, AddressService, HistoricalWeatherServices],
  exports: []
})
export class  TodayWeatherModule {
}
