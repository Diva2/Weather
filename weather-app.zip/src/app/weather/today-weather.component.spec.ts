import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TodayWeatherComponent } from './today-weather.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ResultsModule } from 'app/weather-results/results.module';
import { HttpModule } from '@angular/http';

describe('TodayWeatherComponent', () => {
  let component: TodayWeatherComponent;
  let fixture: ComponentFixture<TodayWeatherComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TodayWeatherComponent],
      imports: [FormsModule, ReactiveFormsModule, ResultsModule, HttpModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TodayWeatherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
