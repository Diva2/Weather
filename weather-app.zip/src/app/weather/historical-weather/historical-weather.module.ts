import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddressService } from 'shared/services/address.service';
import { HistoricalWeatherServices } from 'shared/services/historical-year.service';
import { HistoricalWeatherComponent } from 'app/weather/historical-weather/historical-weather.component';
import { WeatherService } from 'shared/services/weather.service';


@NgModule({
  imports: [CommonModule],
  declarations: [HistoricalWeatherComponent],
  exports: [HistoricalWeatherComponent],
  providers: [AddressService, HistoricalWeatherServices, WeatherService],
  })
export class  HistoricalWeatherModule {
}
