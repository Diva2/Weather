import {Component, Input} from '@angular/core';
import {AddressService} from 'shared/services/address.service';
import { AddressResult } from 'shared/models/address-result';
import { HistoricalWeatherServices } from 'shared/services/historical-year.service';
import { HistoricalResult } from 'shared/models/historical-result';
import { SearchResult } from 'shared/models/search-result';

@Component({
  selector: 'app-history',
  templateUrl: './historical-weather.component.html',
  styleUrls: ['./historical-weather.component.css']
})
export class HistoricalWeatherComponent{
  @Input()historicalResult: HistoricalResult;
  constructor() { }
}