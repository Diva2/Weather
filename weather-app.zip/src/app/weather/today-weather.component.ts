import {Component, OnInit} from '@angular/core';
import {AddressService} from 'shared/services/address.service';
import {WeatherService} from 'shared/services/weather.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {SearchResult} from 'shared/models/search-result';
import { AddressResult } from 'shared/models/address-result';

@Component({
  selector: 'app-find-weather',
  templateUrl: './today-weather.component.html'
})
export class TodayWeatherComponent implements OnInit {
  public searchForm: FormGroup;
  public result: SearchResult;
  public location: AddressResult;
  constructor(private _addressService: AddressService,
     private _weatherService: WeatherService, private _formBuilder: FormBuilder) {
  }

  weatherSearch() {
    const address: any = this.searchForm.value.searchInput;
    this._addressService.getAddressLocation(address).subscribe(
      response => {
        console.log(response);
        this.location = response;
        this._weatherService.getweatherData(this.location)
        .subscribe(
          weatherResponse => {
            console.log(weatherResponse);
            this.result = weatherResponse;
            }, error => console.log(error),
          () => {
            console.log('Executed weather data');
          }
        )
      }, error => console.log(error),
      () => {
        console.log('Executed address');
      }
    );
   }
  
   createSearchForm() {
    this.searchForm = this._formBuilder.group({
      searchInput: ['Bellevue', Validators.required]
    });
  }

  ngOnInit() {
    this.createSearchForm();
  }

}
