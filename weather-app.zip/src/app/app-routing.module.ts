import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { CommonModule } from '@angular/common';
import { TodayWeatherComponent } from 'app/weather/today-weather.component';

const appRoutes: Routes = [
  {
    path: '', component: TodayWeatherComponent, pathMatch: 'prefix'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)
],
  exports: [RouterModule],
  providers: [TodayWeatherComponent]
})
export class AppRoutingModule {
}
