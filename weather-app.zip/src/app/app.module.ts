import {NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import { TodayWeatherModule } from 'app/weather/today-weather.module';
import { ResultsModule } from 'app/weather-results/results.module';

import {AppComponent} from './app.component';
import { TodayWeatherComponent } from 'app/weather/today-weather.component';


@NgModule({
  declarations: [
    AppComponent,
    TodayWeatherComponent
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule,
    TodayWeatherModule,
    ResultsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
