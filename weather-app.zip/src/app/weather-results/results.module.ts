import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ResultsComponent} from './results.component';
import { HistoricalWeatherModule } from 'app/weather/historical-weather/historical-weather.module';
import { HistoricalWeatherServices } from 'shared/services/historical-year.service';
import { WeatherService } from 'shared/services/weather.service';

@NgModule({
  imports: [CommonModule, HistoricalWeatherModule],
  declarations: [ResultsComponent],
  exports: [ResultsComponent],
  providers:[HistoricalWeatherServices, WeatherService]
})
export class ResultsModule {
}
