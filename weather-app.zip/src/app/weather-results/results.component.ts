import { Component, Input} from '@angular/core';
import {SearchResult} from '../../shared/models/search-result';
import { HistoricalResult } from '../../shared/models/historical-result';
import { HistoricalWeatherServices } from 'shared/services/historical-year.service';


@Component({
  selector: 'app-weather-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.css']
})
export class ResultsComponent {
  @Input()searchResult: SearchResult;
  public historicalData: HistoricalResult;
  constructor(private _hisoricalDataService: HistoricalWeatherServices) {

  }

  historicalWeatherData() {
    const lat = this.searchResult.coord.lat;
    const lng = this.searchResult.coord.lon;
    this._hisoricalDataService.getHistoricalWeatherData(lat, lng)
    .subscribe(
      response => {
        this.historicalData = response;
        }, error => console.log(error),
      () => {
        console.log('Executed historical wreather');
      }
    );
  }
  
}
