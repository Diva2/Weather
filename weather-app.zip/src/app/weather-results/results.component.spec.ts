import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpModule } from '@angular/http';
import { HistoricalWeatherModule } from 'app/weather/historical-weather/historical-weather.module';
import { Component, Input, DebugElement } from '@angular/core';
import {By} from '@angular/platform-browser';
//import {ResultsComponent} from 'app/weather-results/results.component';

@Component({
selector: 'test',
template: '{{searchResult}}'
})

class ResultsComponent {
  @Input() searchResult: string;
}

describe('ResultsComponent', () => {
  let component: ResultsComponent;
  let fixture: ComponentFixture<ResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ResultsComponent],
      imports: [HistoricalWeatherModule, HttpModule]
    })
      .compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(ResultsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should correctly render the passed @input value', () => {
    expect(fixture.debugElement.nativeElement.innerHTML).toBe('');
    component.searchResult = 'hello';
    fixture.detectChanges();
    fixture.whenStable().then(() =>{
  expect(fixture.debugElement.nativeElement.innerHTML).toBe('hello');
  });
});
});