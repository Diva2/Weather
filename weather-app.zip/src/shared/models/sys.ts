export interface Sys {
  type: number;
  id: number;
  message: any;
  country: string;
  sunrise: Date;
  sunset: Date;
}


