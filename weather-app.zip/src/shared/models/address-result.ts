export interface AddressResult {
    results: Results[] ;
}

export interface Results {
    geometry: GeoMetry;
}

export interface GeoMetry {
    location: Location;
}
export interface Location {
    lat: number;
    lng: number;
}