export interface HistoricalResult {
  data: Data;
}

export interface Data {
  weather: Weather[];
}
export interface Weather {
  date: Date;
  astronomy: Astronomy[];
  hourly: Hourly[];
  maxtempC: number;
  mintempC: number;
}
export interface Astronomy {
  sunrise: string;
  sunset: string;
}
export interface Hourly {
  time:string;
  winddirDegree: string;
  tempC: string;
  windspeedKmph:  string;
  weatherIconUrl: WeatherIconUrl[];

}
export interface WeatherIconUrl {
value:string;
}
