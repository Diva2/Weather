//API Keys
export const GOOGLE_API_KEY = 'AIzaSyDPnPXQBHJVcuKdCo7Ar39V0JQ3qDwq3AE';
export const API_KEY = '9472cdd50e0d2477f5e2b2491b37d43c';
export const OPEN_WEATHER_API_KEY = '600b1847e13048acb0274155181702';

//API Urls
export const GOOGLE_URL = 'https://maps.googleapis.com/maps/api/geocode/json?address=';
export const WEATHER_URL = 'http://api.openweathermap.org/data/2.5/weather?lat=';
export const OPEN_WEATHER_URL = 'https://api.worldweatheronline.com/premium/v1/past-weather.ashx/?q=';
