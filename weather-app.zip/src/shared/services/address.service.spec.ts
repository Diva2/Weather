import { TestBed, async, inject } from '@angular/core/testing';
import { HttpModule, Response, ResponseOptions, XHRBackend } from '@angular/http';
import {MockBackend} from '@angular/http/testing';
import { AddressService } from 'shared/services/address.service';
import { GOOGLE_URL } from 'shared/shared-data';
import { from } from 'rxjs/observable/from';

describe('AddressService', () => {

  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: [HttpModule],
      providers: [
        { provide: GOOGLE_URL, useValue: 'http://google.com' },
        AddressService,
        {provide: XHRBackend, useClass: MockBackend}
      ]
    });

  });
  describe('getAddressLocation()', () => {
    it('should return an observable<Array<AddressResult>>',
    inject([AddressService, XHRBackend], (addressService, mockBackend) => {
      const mockResponse = {
      data: [
            {'geometry': {'location': {'lat': 47.6101497, 'lng': -122.2015159 }}},
            {'geometry': {'location': {'lat': 47.6101497, 'lng': -122.2015159 }}}
          ]
      };
      mockBackend.connections.subscribe((connection) => {
        connection.mockRespond(new Response(new ResponseOptions({
          body: JSON.stringify(mockResponse)
        })));
      });
      addressService.getAddressLocation().subscribe((address) => {
        expect(address.data['length']).toBe(2);
        expect(address.data[0].geometry.location.lat).toEqual(47.6101497);
        expect(address.data[1].geometry.location.lng).toEqual(-122.2015159);
      });
      }));
  });
});