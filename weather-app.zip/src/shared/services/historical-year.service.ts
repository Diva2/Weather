import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {Http} from '@angular/http';

// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


import {OPEN_WEATHER_API_KEY, OPEN_WEATHER_URL} from '../shared-data';
import {HistoricalResult} from '../models/historical-result';
import { AddressResult } from '../models/address-result';


@Injectable()
export class HistoricalWeatherServices {
  constructor(private _http: Http) {
  }

  getHistoricalWeatherData(lat: number, lng: number): Observable<HistoricalResult> {
    const newCurrentDate = new Date();
    newCurrentDate.setDate(newCurrentDate.getDate() - 1);
     // To get the Yesterday's Date in YYYY MM DD Format
    const currentDate = newCurrentDate.toISOString().slice(0, 10);

    const newEndDate= new Date();
    newEndDate.setMonth(newEndDate.getMonth() - 1);
     // To get the Yesterday's Date in YYYY MM DD Format
    const endDate = newEndDate.toISOString().slice(0, 10);
    return this._http.get(OPEN_WEATHER_URL + lat + ',' + lng + '&format=json&date=' + endDate
     + '&enddate=' + currentDate + '&key=' + OPEN_WEATHER_API_KEY)
      .map(response => {
        return response.json();
       })
      .catch(err => {
        console.log(err);
        return Observable.of(null);
      });
  }
}