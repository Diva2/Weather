import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {Http} from '@angular/http';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {GOOGLE_API_KEY, GOOGLE_URL} from '../shared-data';
import {AddressResult} from '../models/address-result';

@Injectable()
export class AddressService {

  constructor(private _http: Http) {
  }

  getAddressLocation(address: string): Observable<AddressResult> {
    return this._http.get(GOOGLE_URL + address + '&key=' + GOOGLE_API_KEY)
      .map(response => {
        return response.json();
      })
      .catch(err => {
        console.log(err);
        return Observable.of(null);
      });
  }
}
