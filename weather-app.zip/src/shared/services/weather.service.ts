import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {Http} from '@angular/http';

// Import RxJs required methods
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


import {API_KEY, WEATHER_URL} from '../shared-data';
import {SearchResult} from '../models/search-result';
import { AddressResult } from '../models/address-result';

@Injectable()
export class WeatherService {

  constructor(private _http: Http) {
  }

  getweatherData(addressResult: AddressResult): Observable<SearchResult> {

    const lat: number = addressResult.results[0].geometry.location.lat;
    const lng: number = addressResult.results[0].geometry.location.lng;
    return this._http.get(WEATHER_URL + lat + '&lon=' + lng + '&APPID=' + API_KEY)
      .map(response => {
        return response.json();
       })
      .catch(err => {
        console.log(err);
        return Observable.of(null);
      });
  }
}
